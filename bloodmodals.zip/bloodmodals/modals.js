// Import Three.js & OrbitControls as ES modules
import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.152.0/build/three.module.js';
import { OrbitControls } from 'https://cdn.jsdelivr.net/npm/three@0.152.0/examples/jsm/controls/OrbitControls.js';

// Scene setup
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x000000);

const camera = new THREE.PerspectiveCamera(
    75,
    window.innerWidth / window.innerHeight,
    0.1,
    1000
);

const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(window.innerWidth, window.innerHeight);
document.getElementById("dna-scene").appendChild(renderer.domElement);

// Lighting
const light1 = new THREE.PointLight(0x00ffff, 1.5);
light1.position.set(10, 20, 20);
scene.add(light1);

const light2 = new THREE.AmbientLight(0x222222);
scene.add(light2);

// DNA helix
const helix = new THREE.Group();
const helixMaterial = new THREE.MeshPhongMaterial({
    color: 0x00ffff,
    emissive: 0x00ffff,
    emissiveIntensity: 0.6
});

for (let i = 0; i < 100; i++) {
    const angle = i * 0.3;
    const x = Math.cos(angle) * 2;
    const y = i * 0.2 - 10;
    const z = Math.sin(angle) * 2;
    const sphere = new THREE.Mesh(
        new THREE.SphereGeometry(0.12, 16, 16),
        helixMaterial
    );
    sphere.position.set(x, y, z);
    helix.add(sphere);

    const sphere2 = sphere.clone();
    sphere2.position.set(-x, y, -z);
    helix.add(sphere2);
}
scene.add(helix);

// Blood cells
const bloodMaterial = new THREE.MeshPhongMaterial({
    color: 0xff0000,
    emissive: 0xff0000,
    emissiveIntensity: 0.6
});
const bloodCells = [];

for (let i = 0; i < 20; i++) {
    const cell = new THREE.Mesh(
        new THREE.SphereGeometry(0.3, 16, 16),
        bloodMaterial
    );
    cell.position.set(
        (Math.random() - 0.5) * 10,
        (Math.random() - 0.5) * 10,
        (Math.random() - 0.5) * 10
    );
    cell.userData = {
        speedX: (Math.random() - 0.5) * 0.002,
        speedY: (Math.random() - 0.5) * 0.002,
        speedZ: (Math.random() - 0.5) * 0.002
    };
    bloodCells.push(cell);
    scene.add(cell);
}

// Camera position
camera.position.z = 15;

// Controls (lock to X-axis)
const controls = new OrbitControls(camera, renderer.domElement);
controls.enableZoom = false;
controls.enablePan = false;
controls.minPolarAngle = Math.PI / 2;
controls.maxPolarAngle = Math.PI / 2;

// Animate
function animate() {
    requestAnimationFrame(animate);

    // Gentle DNA spin
    helix.rotation.y += 0.002;

    // DNA pulse
    helix.scale.setScalar(1 + Math.sin(Date.now() * 0.002) * 0.02);

    // Move blood cells
    bloodCells.forEach(cell => {
        cell.position.x += cell.userData.speedX;
        cell.position.y += cell.userData.speedY;
        cell.position.z += cell.userData.speedZ;

        if (Math.abs(cell.position.x) > 5) cell.userData.speedX *= -1;
        if (Math.abs(cell.position.y) > 5) cell.userData.speedY *= -1;
        if (Math.abs(cell.position.z) > 5) cell.userData.speedZ *= -1;
    });

    renderer.render(scene, camera);
}
animate();

// Handle resize
window.addEventListener("resize", () => {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
});